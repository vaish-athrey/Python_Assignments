from django.db import models
from orders.models import Order

class TransactionManager(models.Manager):
    def new_or_get(self, client_id, cart_id, order_id):
        order_obj = Order.objects.get(order_id=order_id)
        if order_obj.status == 'created':
            qs = self.get_queryset().filter(client_id=client_id, cart_id=cart_id, order_id = order_id)
            if qs.count() == 1:
                obj = qs.first()
            else:
                obj = self.model.objects.create(client_id=client_id, cart_id=cart_id, order_id = order_id)
            return obj

    def check_unique(self,order_id,tracking_id):
        if self.get_queryset().filter(order_id=order_id, tracking_id=tracking_id).count() >= 1 or self.get_queryset().filter(order_id=order_id).count() >= 1 or self.get_queryset().filter(tracking_id=tracking_id).count() >= 1:
            return False
        else:
            return True
        
# Create your models here.
class Transaction(models.Model):
    order_id = models.CharField(max_length=10, blank=True)
    tracking_id = models.CharField(max_length=20,blank=True)
    bank_ref_no = models.CharField(max_length=20,blank=True)
    order_status = models.CharField(max_length=20,blank=True)
    payment_mode = models.CharField(max_length=40,blank=True)
    card_name = models.CharField(max_length=20,blank=True)
    amount = models.DecimalField(default=0.00, max_digits=100, decimal_places=2)
    billing_name = models.CharField(max_length=120,blank=True)
    billing_email = models.EmailField(blank=True)
    client_id = models.CharField(max_length=120, blank=True)
    cart_id = models.IntegerField(blank=True)
    category = models.CharField(max_length=120, blank=True)
    payment_date = models.CharField(max_length=50,blank=True)

    objects = TransactionManager()
    def __str__(self):
        return self.order_id
