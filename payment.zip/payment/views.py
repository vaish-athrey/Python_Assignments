from django.shortcuts import render
from .ccavutil import encrypt, decrypt
# Create your views here.


def generate_cipher(merchant_id, merchant_param1, merchant_param2, merchant_param3, billing_name, billing_email, order_id, amount, redirect_url, cancel_url, currency="INR", language="EN"):
    working_key = "AC4143B7AA34CE02A832B704C9E8837F"
    enc_str = "merchant_id="+merchant_id+"&"+"order_id="+order_id+"&"+"currency="+currency+"&"+"amount="+amount+"&"+"redirect_url="+redirect_url+"&"+"cancel_url="+cancel_url+"&"+"language="+language+"&"+"merchant_param1="+str(merchant_param1)+"&"+"merchant_param2="+str(merchant_param2)+"&"+"merchant_param3="+merchant_param3+"&"+"billing_name="+billing_name+"&"+"billing_email="+billing_email+"&"
    return encrypt(enc_str,working_key)

def decrypt_cipher(enc):
    working_key = "AC4143B7AA34CE02A832B704C9E8837F"
    return decrypt(enc,working_key)


