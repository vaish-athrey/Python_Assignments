from django.db import models
import decimal
# Create your models here.
from cart.models import Cart
from adipoly.utils import unique_order_id_generator
from django.db.models.signals import pre_save, post_save

from billing.models import BillingProfile
ORDER_STATUS_CHOICES=(
    ('created','Created'),
    ('paid','Paid to bank'),
    ('recieved','Payment Recieved'),
    ('refunded','Refunded'),
)

PAYMENT_STATUS_CHOICES=(
    ('success','Successful'),
    ('fail','Failed'),
    ('not_comp','Yet to be Completed')
)


class OrderManager(models.Manager):
    def new_or_get(self, request, billing_profile, cart_obj):
        qs = self.get_queryset().filter(
            billing_profile=billing_profile, cart=cart_obj, active=True,status="created",payment_status="not_comp")
        if qs.count() == 1:
            obj = qs.first()
        else:
            obj = self.model.objects.create(billing_profile=billing_profile, cart=cart_obj)
            request.session['order_id']=obj.order_id
        return obj
class DiscountCoupon(models.Model):
    discount_code = models.CharField(max_length=120)
    discount_percentage = models.DecimalField(
        default=0.00, max_digits=100, decimal_places=2, null=True, blank=True)


class Order(models.Model):
    order_id = models.CharField(max_length=120, blank=True)
    billing_profile = models.ForeignKey(BillingProfile,null=True,blank=True,on_delete=models.PROTECT)
    cart = models.ForeignKey(Cart,on_delete=models.PROTECT)
    status = models.CharField(max_length=120,default="created",choices=ORDER_STATUS_CHOICES)
    payment_status = models.CharField(max_length=120,default="not_comp",choices=PAYMENT_STATUS_CHOICES)
    active = models.BooleanField(default=True)
    order_total = models.DecimalField(default=0.00, max_digits=100, decimal_places=2)
    discount = models.ForeignKey(DiscountCoupon, on_delete=models.PROTECT,blank=True,null=True)
    taxes = models.DecimalField(
        default=0.00, max_digits=100, decimal_places=2, blank=True, null=True)
    service_charges = models.DecimalField(
        default=0.00, max_digits=100, decimal_places=2, blank=True, null=True)
    def __str__(self): 
        return self.order_id
    
    def update_order_id(self,request):
        self.order_id = unique_order_id_generator(self)
        request.session['order_id']=self.order_id
        self.save()

    def update_total(self):
        cart_obj = self.cart
        cart_total=cart_obj.total
        if cart_obj.category == 'clinic':
            self.service_charges=50
        elif cart_obj.category == 'home':
            if cart_obj.user.distance <= 15:
                self.service_charges = 2000
            else:
                self.service_charges = 3000
        elif cart_obj.category == 'senior':
            if cart_obj.user.distance <= 5:
                service_charges = 500
            elif cart_obj.user.distance <= 10:
                service_charges = 750
            elif cart_obj.user.distance <= 15:
                service_charges = 1000
            elif cart_obj.user.distance <= 20:
                service_charges = 1500
            elif cart_obj.user.distance <= 25:
                service_charges = 2000
            elif cart_obj.user.distance <= 30:
                service_charges = 2500
            else:
                service_charges = 2500 + (cart_obj.user.distance - 30)*100
            if cart_obj.user.assist == 'Y':
                service_charges += 200
            self.service_charges = service_charges
        self.taxes = round(decimal.Decimal(0.18)*(cart_total+self.service_charges))
        discount=0
        if self.discount is not None:
            discount = (self.discount.discount_percentage/100)*cart_total
        new_total = cart_total-discount+self.taxes+self.service_charges
        self.order_total = round(new_total)
        self.save()
        return new_total

    objects=OrderManager()

#generate order_id. order_id is random and unique(must)
 


def pre_save_create_order_id(sender,instance,*args,**kwargs):
    if not instance.order_id:
        instance.order_id = unique_order_id_generator(instance)
    qs = Order.objects.filter(cart=instance.cart).exclude(billing_profile=instance.billing_profile)
    if qs.exists():
        qs.update(active=False)
pre_save.connect(pre_save_create_order_id, sender=Order)

#generate order_total

def post_save_cart_total(sender,instance,created,*args,**kwargs):
    if not created:
        cart_obj=instance
        cart_total  = cart_obj.total
        cart_id = cart_obj.id
        qs = Order.objects.filter(cart__id=cart_id)
        if qs.count() == 1:
            order_obj = qs.first()
            order_obj.update_total()

post_save.connect(post_save_cart_total,sender=Cart)


def post_save_order(sender,instance,created,*args,**kwargs):
    if created:
        instance.update_total()


post_save.connect(post_save_order, sender=Order)





