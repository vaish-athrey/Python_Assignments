from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models.signals import pre_save

# Create your models here.
from adipoly.utils import unique_client_id_generator
from phonenumber_field.modelfields import PhoneNumberField

Gender_Choice = (
    ('M', 'Male'),
    ('F', 'Female'),
    ('O', 'Others'),
)
Covid_Choice = (
    ('Y', 'Yes'),
    ('N', 'No'),
)
po_ne_choices = (('P', 'Positive'), ('N', 'Negative'))

class UserManager(models.Manager):
    def new_or_get_client_id(self,email_id,sex,date_birth):
        qs = self.get_queryset().filter(email = email_id,sex = sex,dob = date_birth) 
        if qs.count()==1:
            client_id = qs.first().client_id;
        else:
            client_id = None
        return client_id


class User(models.Model):
    name = models.CharField(max_length=100)
    dob = models.DateField(max_length=8)
    age = models.IntegerField(validators=[MaxValueValidator(110), MinValueValidator(1)])
    sex = models.CharField(max_length=1, choices=Gender_Choice)
    email = models.EmailField(max_length=110)
    ph_no = PhoneNumberField(max_length=13)
    address_line_0 = models.TextField(blank=True, null=True, max_length=30)
    address_line_1 = models.TextField(blank=True, null=True, max_length=60)
    address_line_2 = models.TextField(blank=True, null=True, max_length=100)
    city = models.TextField(blank=True, null=True)
    pin_code = models.CharField(blank=True, null=True, max_length=6)
    landmark = models.TextField(blank=True, null=True)
    date = models.DateField(null=True, blank=True,auto_now=False, auto_now_add=False)
    slot = models.IntegerField(validators=[MaxValueValidator(12), MinValueValidator(1)], blank=True, null=True)
    service_address = models.TextField(blank=True, null=True, max_length=256)
    distance = models.IntegerField(null=True, blank=True)
    assist = models.CharField(max_length=1, choices=Covid_Choice, blank=True,null=True)
    covid_tested = models.CharField(max_length=1, choices=Covid_Choice, default='N')
    covid_declaration = models.CharField(max_length=1, choices=po_ne_choices, default='N')
    covid_treated = models.CharField(max_length=1, choices=Covid_Choice, default='N')
    covid_vaccinated = models.CharField(max_length=1, choices=Covid_Choice, default='N')
    client_id = models.CharField(max_length=120, blank=True)

    objects = UserManager()

    def __str__(self):
        return self.name


def pre_save_create_client_id(sender, instance, *args, **kwargs):
    if not instance.client_id:
        instance.client_id = unique_client_id_generator(instance)


pre_save.connect(pre_save_create_client_id, sender=User)
