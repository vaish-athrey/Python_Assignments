from django.shortcuts import render, redirect

from adipoly.views import appointment,determine_day
# Create your views here.
from cart.models import Cart
from django.forms import ValidationError
from .models import User
def user_registeration(request):
    #user registeration view
    #recieves POST data from the page about the user and adds the data into a new object of the user model
    cart_obj,_ = Cart.objects.new_or_get(request)
    if cart_obj.user is not None:
        return redirect(appointment, client_id=cart_obj.user.client_id,cart_no=cart_obj.id)
    if request.method == "POST":
        new_user = User()
        new_user.name = request.POST.get('first_name')
        try:
            date_birth=new_user.dob = request.POST.get('birth_date')
        except ValidationError:
            context = {}
            context['message']="Please enter Date of Birth in YYYY-MM-DD format"
            return render(request, "user/Patient-Information.html", context)
        new_user.age = request.POST.get('age')
        gender = request.POST.get('gender')
        if gender == 'male':
            sex=new_user.sex = 'M'
        elif gender == 'female':
            sex=new_user.sex = 'F'
        else:
            sex=new_user.sex = 'O'
        email=new_user.email = request.POST.get('email')
        ph = request.POST.get('phone_number')
        new_user.ph_no = validate(ph)
        new_user.address_line_0 = request.POST.get('address_0')
        new_user.address_line_1 = request.POST.get('address_1')
        new_user.address_line_2 = request.POST.get('address_2')
        new_user.city = request.POST.get('city')
        new_user.pin_code = request.POST.get('pin')
        new_user.landmark = request.POST.get('landmark')
        covid_tested = request.POST.get('covid-test')
        if covid_tested == 'covid-yes':
            new_user.covid_tested = 'Y'
            covid_res = request.POST.get('covid-res')
            if covid_res == 'covid-pos':
                new_user.covid_declaration = 'P'
            else:
                new_user.covid_declaration = 'N'
            covid_treat = request.POST.get('covid-treat')
            if covid_treat == 'covid-treat-yes':
                new_user.covid_treated = 'Y'
            else:
                new_user.covid_treated = 'N'
        else:
            new_user.covid_tested = 'N'
            new_user.covid_declaration = 'N'
            new_user.covid_treated = 'N'
        covid_vac = request.POST.get('covid-vac')
        if covid_vac is 'covid_vac_yes':
            new_user.covid_vaccinated = 'Y'
        else:
            new_user.covid_vaccinated = 'N'
        cart_obj.category = 'clinic'
        try:
            new_user.save()
        except ValidationError:
            context = {}
            context['message'] = "Please enter Date of Birth in YYYY-MM-DD format"
            return render(request, "user/Patient-Information.html", context)
        except:
            context = {}
            context['message'] = "There was an error with the entered data. Please Try Again"
            return render(request, "user/Patient-Information.html", context)
        new_user.save()
        cart_obj.user = new_user
        cart_obj.save()
        return redirect(appointment, client_id=new_user.client_id, cart_no=cart_obj.id)
    return render(request, "user/Patient-Information.html")


def user_edit(request, client_id):
    #This function loads the user_edit view and saves the new data entered by the user
    cart_obj,_ = Cart.objects.new_or_get(request)
    user = User.objects.filter(client_id=client_id).first()
    if request.method == "POST":
        user.name = request.POST.get('first_name')
        try:
            date_birth = user.dob = request.POST.get('birth_date')
        except ValidationError:
            context = {}
            context['message'] = "Please enter Date of Birth in YYYY-MM-DD format"
            return render(request, "user/User-edit.html", context)
        user.age = request.POST.get('age')
        gender = request.POST.get('gender')
        if gender == 'male':
            sex=user.sex = 'M'
        elif gender == 'female':
            sex=user.sex = 'F'
        else:
            sex=user.sex = 'O'
        email=user.email = request.POST.get('email')
        ph = request.POST.get('phone_number')
        user.ph_no = validate(ph)
        user.address_line_0 = request.POST.get('address_0')
        user.address_line_1 = request.POST.get('address_1')
        user.address_line_2 = request.POST.get('address_2')
        user.city = request.POST.get('city')
        user.pin_code = request.POST.get('pin')
        user.landmark = request.POST.get('landmark')
        covid_tested = request.POST.get('covid-test')
        if covid_tested == 'covid-yes':
            user.covid_tested = 'Y'
            covid_res = request.POST.get('covid-res')
            if covid_res == 'covid-pos':
                user.covid_declaration = 'P'
            else:
                user.covid_declaration = 'N'
            covid_treat = request.POST.get('covid-treat')
            if covid_treat == 'covid-treat-yes':
                user.covid_treated = 'Y'
            else:
                user.covid_treated = 'N'
        else:
            user.covid_tested = 'N'
            user.covid_declaration = 'N'
            user.covid_treated = 'N'
        covid_vac = request.POST.get('covid-vac')
        if covid_vac is 'covid_vac_yes':
            user.covid_vaccinated = 'Y'
        else:
            user.covid_vaccinated = 'N'
        try:
            user.save()
        except ValidationError:
            context = {}
            context['user'] = user
            context['cart'] = cart_obj
            context['message'] = "Please enter Date of Birth in YYYY-MM-DD format"
            return render(request, "User-edit.html", context)
        except:
            context = {}
            context['user'] = user
            context['cart'] = cart_obj
            context['message'] = "There was an error with the entered data. Please Try Again"
            return render(request, "User-edit.html", context)
        cart_obj.user = user
        cart_obj.save()
        return redirect(appointment, client_id=user.client_id, cart_no=cart_obj.id)
    context = {}
    context['user'] = user
    context['cart'] = cart_obj
    return render(request, "user/User-edit.html", context)



def validate(ph):
    #This function validates the phone number entered by the user to add the country code '+91'
    if len(ph) == 13 and ph[0:3] == '+91':
        return ph
    elif len(ph) == 12 and ph[0:2] == '91':
        ph = '+'+ph
        return ph
    elif len(ph) == 10:
        ph = "+91"+ph
        return ph

