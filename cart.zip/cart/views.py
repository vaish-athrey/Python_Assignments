from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from .models import Cart
from adipoly.models import Tests
import urllib.request
import urllib.parse


# Create your views here.
#from adipoly.views import *
from payment.views import decrypt_cipher

def cart_home(request):
    #cart page view
    cart_obj,new_obj = Cart.objects.new_or_get(request)
    context = {}
    context["cart"] = cart_obj
    context["packages"] = cart_obj.package.all()
    context["products"] = cart_obj.products.all()
    request.session['cart_items'] = cart_obj.products.count() + cart_obj.package.count()
    return render(request, 'cart/Cart.html', context)


def cart_update(request):
    #function to remove items from cart
    product_id = request.POST.get('test_uid')
    if request.is_ajax():
        print("Ajax Request")
    if product_id != None:
        try:
            product_obj = Tests.objects.get(test_id=product_id)
        except Tests.DoesNotExist:
            return redirect(cart_home)
        cart_obj, new_obj = Cart.objects.new_or_get(request)
        # if not cart_obj.active:
        #     cat = cart_obj.category
        #     user = cart_obj.user
        #     request.session['cart_message']="Attempting to add items to the cart during payment confirmation is not allowed. Please click on edit to modify your cart"
        #     if cat=='home':
        #         return HttpResponseRedirect(reverse('book_home_slot',kwargs={'client_id':user.client_id,'cart_no':cart_obj.id}))
        #     if cat == 'senior':
        #         return HttpResponseRedirect(reverse('book_senior_slot', kwargs={'client_id': user.client_id, 'cart_no': cart_obj.id}))
        #     if cat == 'clinic':
        #         return HttpResponseRedirect(reverse('book_slot', kwargs={'client_id': user.client_id, 'cart_no': cart_obj.id}))
        # elif cart_obj.active:
        if product_obj in cart_obj.products.all():
            cart_obj.products.remove(product_obj)
        else:
            cart_obj.products.add(product_obj)
        request.session['cart_items'] = cart_obj.products.count() + cart_obj.package.count()
    return redirect(cart_home)
