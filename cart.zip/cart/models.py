from django.db import models
from django.urls import reverse
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models.signals import pre_save, post_save, m2m_changed
import datetime
import decimal
from adipoly.models import Tests, Package
from user.models import User
# Create your models here.


class CartManager(models.Manager):
    def new_or_get(self, request):
        cart_id = request.session.get("cart_id", None)
        qs = self.get_queryset().filter(id=cart_id,transaction_complete=False,lock=False)
        if qs.count() == 1:
            new_obj = False
            cart_obj = qs.first()
        else:
            new_obj = True
            cart_obj = Cart.objects.new(user=None)
            request.session['cart_id'] = cart_obj.id
        return cart_obj, new_obj

    def new(self, user=None):
        user_obj = None
        if user is not None:
            user_obj = user
        return self.model.objects.create(user=user_obj)


CART_STATUS_CHOICES = (
    ("clinic", "Clinic"),
    ("senior", "Senior"),
    ("home", "Home"),
)


class Cart(models.Model):
    user = models.ForeignKey(
        to= User, null=True, blank=True, on_delete=models.CASCADE)
    products = models.ManyToManyField(Tests, blank=True)
    package = models.ManyToManyField(Package, blank=True)
    subtotal = models.DecimalField(
        default=0.00, max_digits=100, decimal_places=2)
    total = models.DecimalField(default=0.00, max_digits=100, decimal_places=2)
    updated = models.DateTimeField(auto_now=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    # active = models.BooleanField(default=True)
    transaction_complete = models.BooleanField(default=False)
    lock = models.BooleanField(default=False)
    category = models.CharField(
        max_length=120, default="clinic", choices=CART_STATUS_CHOICES)
    objects = CartManager()

    def __str__(self):
        return str(self.id)


def m2m_changed_cart_product_reciever(sender, instance, action, *args, **kwargs):
    if action == "post_add" or action == "post_remove" or action == "post_clear":
        products = instance.products.all()
        packages = instance.package.all()
        total = 0
        for product in products:
            total += product.price
        for package in packages:
            total += package.total
        if instance.subtotal != total:
            instance.subtotal = total
            instance.save()


m2m_changed.connect(m2m_changed_cart_product_reciever,
                    sender=Cart.products.through)
m2m_changed.connect(m2m_changed_cart_product_reciever,
                    sender=Cart.package.through)


def pre_save_cart_reciever(sender, instance, *args, **kwargs):
    if instance.category == "clinic" or instance.category == "senior":
        instance.discount = 50
    elif instance.category == "home":
        instance.discount = 0
    if instance.subtotal > 0:
        instance.total = instance.subtotal - (decimal.Decimal(instance.discount/100)*instance.subtotal)
    elif instance.subtotal == 0:
        instance.total = 0.0


pre_save.connect(pre_save_cart_reciever, sender=Cart)
