from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from cart.models import Cart
from user.models import User
from orders.models  import Order
from cart.views import cart_home
from .models import BillingProfile
from time_slots.models import Slot1, Slot2, Slot3, Slot4, Slot5, Slot6, Slot7, Slot8, Slot9, Slot10, Slot11, Slot12
from adipoly.models import home_service,senior_service
from django.views.decorators.csrf import csrf_exempt
import datetime
from django.urls import reverse
from payment.views import decrypt_cipher
# Create your views here.
from payment.models import Transaction
import json
import requests
from payment.ccavutil import encrypt,decrypt

merchant_id = "395767"
access_code = "AVSG09IF56AB20GSBA"

@csrf_exempt
def checkout_recieve(request):
    if request.POST:
        r = request.POST
        enc = r.get('encResp')
        response = decrypt_cipher(enc).split('&')
        order_id=response[0].split('=')[1]
        client_id = response[26].split('=')[1]
        cart_id = int(response[27].split('=')[1])
        tracking_id= response[1].split('=')[1]
        if not Transaction.objects.check_unique(order_id,tracking_id):
            request.session['message'] = "Transaction Not Unique"
            return HttpResponseRedirect(reverse('payment_fail'))
        try:
            t = Transaction()
            t.order_id = order_id
            t.client_id = client_id
            t.cart_id = cart_id
            t.tracking_id= tracking_id
            t.bank_ref_no= response[2].split('=')[1]
            t.order_status= response[3].split('=')[1]
            t.payment_mode= response[5].split('=')[1]
            t.card_name = response[6].split('=')[1]
            t.amount = float(response[10].split('=')[1])
            t.billing_name = response[11].split('=')[1]
            t.billing_email = response[18].split('=')[1]
            t.category = response[28].split('=')[1]
            t.payment_date = response[40].split('=')[1]
            t.save()
            request.session['order_id'] = order_id 
            request.session['success_cart_id']=cart_id
            return HttpResponseRedirect(reverse('checkout'))
        except:
            request.session['message'] = "Transaction Not Unique"
            return HttpResponseRedirect(reverse('payment_fail'))

def checkout_home(request):
    try:
        cart_id =  request.session.get('success_cart_id')
        try:
            cart_obj = Cart.objects.get(id=cart_id)
        except:
            request.session['message'] = 'Transaction Invalid'
            return HttpResponseRedirect(reverse('payment_fail'))
        orderid = request.session.get('order_id')
        order_obj = Order.objects.get(order_id=orderid)
        t = Transaction.objects.get(cart_id = cart_obj.id,order_id = order_obj.order_id)
        user = cart_obj.user
    except:
        cart_id =  request.session.get('success_cart_id')
        cart_obj = Cart.objects.get(id=cart_id)
        cart_obj.lock = False
        cart_obj.save()
        request.session['cart_id']=cart_id
        del request.session['success_cart_id']
        request.session['message'] = 'Transaction Invalid'
        return HttpResponseRedirect(reverse('payment_fail'))
    # print(cart_obj,cart_obj.user)
    if order_obj.order_id == t.order_id and order_obj.order_total==t.amount and status(order_obj.order_id,t.tracking_id,order_obj.order_total) :
        slot=get_slot(user.slot,user.date)
        if order_obj.status == 'created':
            if t.category=="Clinic":
                get_customer(slot,user)
            if t.category=="Home":
                book_home_slot(user,user.date)
            if t.category == "Senior":
                book_senior_slot(user, user.date)
        cart_obj.transaction_complete=True
        cart_obj.save()
        context={}
        context["slot"] = slot
        context["user"] = user
        context["cart"] = cart_obj
        context["order"] = order_obj
        context['amt'] = t.amount
        context['bank_ref'] = t.bank_ref_no
        context['billing_name'] = t.billing_name
        context['billing_email'] = t.billing_email
        context['transaction_date'] = t.payment_date
        context['order_st']= t.order_status
        if t.order_status == "Success" and t.bank_ref_no != "None":
            order_obj.status = 'paid'
            order_obj.payment_status = 'success'
            order_obj.save()
        return render(request,"billing/Checkout.html",context)
    else:
        cart_obj.lock = False
        cart_obj.save()
        request.session['cart_id']=cart_obj.id
        del request.session['success_cart_id']
        request.session['message'] = 'Tampered Transaction!'
        return HttpResponseRedirect(reverse('payment_fail'))

# Tracking ID for status API is Bank Refrence Number

#['order_id=GPQJLKGTJC', 'tracking_id=310007244481', 'bank_ref_no=1623299809934', 'order_status=Success', 
# 'failure_message=', 'payment_mode=Credit Card', 'card_name=Visa', 'status_code=null', 
# 'status_message=Y', 'currency=INR', 'amount=2127.50', 'billing_name=Test',
# 'billing_address=', 'billing_city=', 'billing_state=', 'billing_zip=', 
# 'billing_country=', 'billing_tel=', 'billing_email=', 'delivery_name=', 
# 'delivery_address=', 'delivery_city=', 'delivery_state=', 'delivery_zip=', 
# 'delivery_country=', 'delivery_tel=', 'merchant_param1=BAHS9VM4061P2021', 'merchant_param2=10', 
# 'merchant_param3=', 'merchant_param4=', 'merchant_param5=', 'vault=N', 
# 'offer_type=null', 'offer_code=null', 'discount_value=0.0', 'mer_amount=2127.50', 
# 'eci_value=null', 'retry=N', 'response_code=0', 'billing_notes=', 
# 'trans_date=10/06/2021 10:07:29', 'bin_country=INDIA']


@csrf_exempt
def payment_fail(request):
    if request.POST:
        print('YESSS')
        r = request.POST
        enc = r.get('encResp')
        response = decrypt_cipher(enc).split('&')
        order_id = response[0].split('=')[1]
        client_id = response[26].split('=')[1]
        cart_id = int(response[27].split('=')[1])
        tracking_id= response[1].split('=')[1]
        request.session['order_id'] = order_id
        request.session['cart_id'] = cart_id
        if not Transaction.objects.check_unique(order_id, tracking_id):
            request.session['message'] = "Transaction Not Unique"
            return HttpResponseRedirect(reverse('payment_fail'))
        t = Transaction()
        t.order_id = order_id
        t.order_status = response[3].split('=')[1]
        t.client_id = client_id
        t.cart_id = cart_id
        t.tracking_id = tracking_id
        t.save()
        return HttpResponseRedirect(reverse('payment_fail'))

        
def paymentfailed(request):
    try:
        cart_id =  request.session['cart_id']
        cart_obj = Cart.objects.get(id=cart_id)
        cart_obj.lock = False
        cart_obj.save()
        user =  cart_obj.user
        billing_profile, billing_profile_created = BillingProfile.objects.get_or_create(user=user, email=user.email)
        order_id = request.session['order_id']
        order_obj = Order.objects.get(order_id=order_id)
        order_obj.payment_status = "fail"
        order_obj.save()
        # new_order = Order.objects.new_or_get(request,billing_profile, cart_obj)
        t = Transaction.objects.get(cart_id = cart_obj.id,order_id = order_obj.order_id)
        context={}
        context["user"] = user
        context["cart"] = cart_obj
        context["order"] = order_obj
        context['order_st']=t.order_status
        context["message"] = request.session.get('message')
        return render(request,'billing/Payment-Fail.html',context)
    except:
        context={}
        context["message"] = request.session.get('message')
        return render(request,'billing/Payment-Fail.html',context)

# order_id=A2L2SA8VKZ&tracking_id=310007238226&bank_ref_no=null&
# order_status=Aborted&failure_message=&payment_mode=null&card_name=null&
# status_code=&status_message=Cancel reason is not specified by the customer.
# &currency=INR&amount=920.00&billing_name=&billing_address=&billing_city=&
# billing_state=&billing_zip=&billing_country=&billing_tel=&billing_email=&
# delivery_name=&delivery_address=&delivery_city=&delivery_state=&delivery_zip=&
# delivery_country=&delivery_tel=&merchant_param1=&merchant_param2=&
# merchant_param3=&merchant_param4=&merchant_param5=&vault=N&offer_type=null&
# offer_code=null&discount_value=0.0&mer_amount=920.00&eci_value=&retry=null&
# response_code=&billing_notes=&trans_date=null&bin_country=

def get_slot(slot, date):
    if slot == 1:
        return Slot1.objects.get(date=date)
    elif slot == 2:
        return Slot2.objects.get(date=date)
    elif slot == 3:
        return Slot3.objects.get(date=date)
    elif slot == 4:
        return Slot4.objects.get(date=date)
    elif slot == 5:
        return Slot5.objects.get(date=date)
    elif slot == 6:
        return Slot6.objects.get(date=date)
    elif slot == 7:
        return Slot7.objects.get(date=date)
    elif slot == 8:
        return Slot8.objects.get(date=date)
    elif slot == 9:
        return Slot9.objects.get(date=date)
    elif slot == 10:
        return Slot10.objects.get(date=date)
    elif slot == 11:
        return Slot11.objects.get(date=date)
    elif slot == 12:
        return Slot12.objects.get(date=date)


def get_customer(slot, customer):
    if slot.slots_left == 10:
        slot.customer1 = customer
        slot.save()
        return
    elif slot.slots_left == 9:
        slot.customer2 = customer
        slot.save()
        return
    elif slot.slots_left == 8:
        slot.customer3 = customer
        slot.save()
        return
    elif slot.slots_left == 7:
        slot.customer4 = customer
        slot.save()
        return
    elif slot.slots_left == 6:
        slot.customer5 = customer
        slot.save()
        return
    elif slot.slots_left == 5:
        slot.customer6 = customer
        slot.save()
        return
    elif slot.slots_left == 4:
        slot.customer7 = customer
        slot.save()
        return
    elif slot.slots_left == 3:
        slot.customer8 = customer
        slot.save()
        return
    elif slot.slots_left == 2:
        slot.customer9 = customer
        slot.save()
        return
    elif slot.slots_left == 1:
        slot.customer10 = customer
        slot.save()
        return

def book_home_slot(user,date):
    home = home_service()
    home.user = user
    home.date = date
    home.save()


def book_senior_slot(user, date):
    snr = senior_service()
    snr.user = user
    snr.date = date
    snr.save()

def status(order_no,ref_no,or_amt):
    aurl = "https://logintest.ccavenue.com/apis/servlet/DoWebTrans"
    merchant_id = "395767"
    access_code = "AVSG09IF56AB20GSBA"
    request_type = "JSON"
    command = "orderStatusTracker"
    working_key = "AC4143B7AA34CE02A832B704C9E8837F"
    param = "{'order_no': '"+order_no+"'}"
    enc_r = encrypt(param, working_key)
    params = {
        'enc_request': enc_r,
        'access_code': "AVSG09IF56AB20GSBA",
        'request_type':'JSON',
        'response_type':'JSON',
        'command': "orderStatusTracker",
        'version':"1.2",
    }
    r = requests.post(aurl, params)
    r = r.text.split('&')
    enc_r = r[1].split('=')[1]
    enc_r = enc_r[:-2]
    res=decrypt(enc_r,working_key)
    res = json.loads(res)
    ref = res['reference_no']
    amt = res['order_amt']
    status = res['order_status']
    if ref == ref_no and amt == or_amt and status == "Shipped":
        return True
    else:
        return False

# {'reference_no': '310007251498', 'order_no': 'GPQJLKGTJC', 'order_currncy': 'INR', 
# 'order_amt': 2127.5, 'order_date_time': '2021-06-12 14:28:06.07', 'order_bill_name': 'Poorvik Dharmendra', 
# 'order_bill_address': '', 'order_bill_zip': '', 'order_bill_tel': '', 'order_bill_email': 'pratheekdharmendra@gmail.com', 
# 'order_bill_country': '', 'order_ship_name': '', 'order_ship_address': '', 'order_ship_country': '', 'order_ship_tel': '', 
# 'order_bill_city': '', 'order_bill_state': '', 'order_ship_city': '', 'order_ship_state': '', 'order_ship_zip': '',
# 'order_ship_email': '', 'order_notes': '', 'order_ip': '106.51.140.198', 'order_status': 'Shipped', 
# 'order_fraud_status': 'NA', 'order_status_date_time': '2021-06-12 14:28:15.103', 'order_capt_amt': 2127.5,
# 'order_card_name': 'AvenuesTest', 'order_delivery_details': '', 'order_fee_perc': 0.0, 
# 'order_fee_perc_value': 0.0, 'order_fee_flat': 0.0, 'order_gross_amt': 2127.5, 
# 'order_discount': 0.0, 'order_tax': 0.0, 'order_bank_ref_no': '1623488254221', 
# 'order_gtw_id': 'AVN', 'order_bank_response': 'Y', 'order_option_type': 'OPTNBK', 
# 'order_TDS': 0.0, 'order_device_type': 'PC', 'param_value1': 'BAHS9VM4061P2021', 
# 'param_value2': '10', 'param_value3': '', 'param_value4': '', 'param_value5': '', 
# 'error_desc': '', 'status': 0, 'error_code': ''}
