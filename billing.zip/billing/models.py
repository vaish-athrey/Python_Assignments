from django.db import models

from user.models import User

from django.db.models.signals import post_save
# Create your models here.
class BillingProfile(models.Model):
    user    = models.OneToOneField(User,null=True,blank=True,on_delete=models.PROTECT )
    email   = models.EmailField()
    timestamp = models.DateTimeField(auto_now_add=True)
    update = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.email

def user_created_reciever(sender,instance,created,*args, **kwargs):
    if created and instance.email:
        BillingProfile.objects.get_or_create(user=instance,email=instance.email)

post_save.connect(user_created_reciever,sender=User)

def post_save_user(sender,instance,created,*args,**kwargs):
    if not created:
        user_obj=instance
        b=BillingProfile.objects.get(user=instance)
        b.email=user_obj.email
        b.save()
post_save.connect(post_save_user,sender=User)