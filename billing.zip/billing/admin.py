from django.contrib import admin

# Register your models here.
from .models import BillingProfile

admin.site.register(BillingProfile)