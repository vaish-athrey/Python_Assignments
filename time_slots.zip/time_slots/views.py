from django.shortcuts import render
import datetime
# Create your views here.
from adipoly.models import Day1,Day2,Day3
from .models import Slot1, Slot2, Slot3, Slot4, Slot5, Slot6, Slot7, Slot8, Slot9, Slot10, Slot11, Slot12
def create_slot(day):
    #To create 12 slots for a particular day. day is Day1,Day2 or Day3 model object
    Slot1.objects.create(date=day.date)
    Slot2.objects.create(date=day.date)
    Slot3.objects.create(date=day.date)
    Slot4.objects.create(date=day.date)
    Slot5.objects.create(date=day.date)
    Slot6.objects.create(date=day.date)
    Slot7.objects.create(date=day.date)
    Slot8.objects.create(date=day.date)
    Slot9.objects.create(date=day.date)
    Slot10.objects.create(date=day.date)
    Slot11.objects.create(date=day.date)
    Slot12.objects.create(date=day.date)


def slot_aggregator(day):
    #To aggregate all the slots of a particluar day into an array
    return [Slot1.objects.get(date=day.date), Slot2.objects.get(date=day.date), Slot3.objects.get(date=day.date), Slot4.objects.get(date=day.date),
            Slot5.objects.get(date=day.date), Slot6.objects.get(
                date=day.date), Slot7.objects.get(date=day.date), Slot8.objects.get(date=day.date),
            Slot9.objects.get(date=day.date), Slot10.objects.get(date=day.date), Slot11.objects.get(date=day.date), Slot12.objects.get(date=day.date)]


def determine_day():
    #To determine the three days slots can be booked for and add the dates in the database
    tod = datetime.date.today()
    a = datetime.timedelta(days=1)
    tom = tod+a
    day_aft = tom+a
    d1 = Day1.objects.filter(date=tod).exists()
    d2 = Day2.objects.filter(date=tod).exists()
    d3 = Day3.objects.filter(date=tod).exists()
    if (not d1 and d2 and not d3):
        if not Day1.objects.filter(date=day_aft).exists():
            new_day_1 = Day1()
            new_day_1.date = day_aft
            new_day_1.save()
            create_slot(new_day_1)
        if not Day3.objects.filter(date=tom).exists():
            new_day_3 = Day3()
            new_day_3.date = tom
            new_day_3.save()
            create_slot(new_day_3)
        return (Day2.objects.get(date=tod), Day3.objects.get(date=tom), Day1.objects.get(date=day_aft))
    elif (not d1 and not d2 and d3):
        if not Day2.objects.filter(date=day_aft).exists():
            new_day_2 = Day2()
            new_day_2.date = day_aft
            new_day_2.save()
            create_slot(new_day_2)
        if not Day1.objects.filter(date=tom).exists():
            new_day_1 = Day1()
            new_day_1.date = tom
            new_day_1.save()
            create_slot(new_day_1)
        return (Day3.objects.get(date=tod), Day1.objects.get(date=tom), Day2.objects.get(date=day_aft))
    elif (d1 and not d2 and not d3):
        if not Day3.objects.filter(date=day_aft).exists():
            new_day_3 = Day3()
            new_day_3.date = day_aft
            new_day_3.save()
            create_slot(new_day_3)
        if not Day2.objects.filter(date=tom).exists():
            new_day_2 = Day2()
            new_day_2.date = tom
            new_day_2.save()
            create_slot(new_day_2)
        return (Day1.objects.get(date=tod), Day2.objects.get(date=tom), Day3.objects.get(date=day_aft))
    elif (not d1 and not d2 and not d3):
        new_day_1 = Day1()
        new_day_1.date = tod
        new_day_1.save()
        new_day_2 = Day2()
        new_day_2.date = tom
        new_day_2.save()
        new_day_3 = Day3()
        new_day_3.date = day_aft
        new_day_3.save()
        create_slot(new_day_1)
        create_slot(new_day_2)
        create_slot(new_day_3)
        return (new_day_1, new_day_2, new_day_3)

