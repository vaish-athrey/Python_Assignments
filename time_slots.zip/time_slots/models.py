from django.db import models
from user.models import User
import datetime
# Create your models here.

from django.db.models.signals import pre_save
class Slot1(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(7, 00, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(7, 30, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_1_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot2(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(7, 30, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(8, 00, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_2_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot3(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(8, 00, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(8, 30, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_3_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot4(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(8, 30, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(9, 00, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_4_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot5(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(9, 00, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(9, 30, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_5_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot6(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(9, 30, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(10, 00, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_6_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot7(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(10, 00, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(10, 30, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_7_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot8(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(10, 30, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(11, 00, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_8_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot9(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(11, 00, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(11, 30, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_9_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot10(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(11, 30, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(12, 00, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_10_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot11(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(12, 00, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(12, 30, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_11_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


class Slot12(models.Model):
    time_begin = models.TimeField(
        default=datetime.time(12, 30, 00), editable=False)
    time_end = models.TimeField(
        default=datetime.time(13, 00, 00), editable=False)
    slots_left = models.IntegerField(default=10)
    date = models.DateField(null=True, blank=True,
                            auto_now=False, auto_now_add=False)
    customer1 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_1")
    customer2 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_2")
    customer3 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_3")
    customer4 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_4")
    customer5 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_5")
    customer6 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_6")
    customer7 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_7")
    customer8 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_8")
    customer9 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_9")
    customer10 = models.ForeignKey(
        to=User, null=True, blank=True, on_delete=models.CASCADE, related_name="customer_12_10")
    free = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.date} {self.time_begin} to {self.time_end} ({self.slots_left})"


def pre_save_slot_reciever(sender, instance, *args, **kwargs):
    count = 0
    customers = [instance.customer1, instance.customer2, instance.customer3, instance.customer4, instance.customer5,
                 instance.customer6, instance.customer7, instance.customer8, instance.customer9, instance.customer10, ]
    for customer in customers:
        if customer == None:
            count += 1
    if count == 0:
        instance.free = False
    instance.slots_left = count


pre_save.connect(pre_save_slot_reciever, sender=Slot1)
pre_save.connect(pre_save_slot_reciever, sender=Slot2)
pre_save.connect(pre_save_slot_reciever, sender=Slot3)
pre_save.connect(pre_save_slot_reciever, sender=Slot4)
pre_save.connect(pre_save_slot_reciever, sender=Slot5)
pre_save.connect(pre_save_slot_reciever, sender=Slot6)
pre_save.connect(pre_save_slot_reciever, sender=Slot7)
pre_save.connect(pre_save_slot_reciever, sender=Slot8)
pre_save.connect(pre_save_slot_reciever, sender=Slot9)
pre_save.connect(pre_save_slot_reciever, sender=Slot10)
pre_save.connect(pre_save_slot_reciever, sender=Slot11)
pre_save.connect(pre_save_slot_reciever, sender=Slot12)
